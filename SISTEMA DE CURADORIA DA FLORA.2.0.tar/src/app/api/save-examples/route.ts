import { NextRequest, NextResponse } from 'next/server'

interface LearningExample {
  id: string
  type: 'approved' | 'rejected'
  description: string
  reason: string
  timestamp: Date
}

interface SaveExamplesRequest {
  examples: LearningExample[]
}

// Em um ambiente real, isso salvaria em um banco de dados
// Por agora, vamos salvar em um arquivo JSON local
let savedExamples: LearningExample[] = []

export async function POST(request: NextRequest) {
  try {
    const body: SaveExamplesRequest = await request.json()
    const { examples } = body

    if (!Array.isArray(examples)) {
      return NextResponse.json(
        { error: 'Exemplos devem ser um array' },
        { status: 400 }
      )
    }

    // Validar estrutura dos exemplos
    const validExamples = examples.filter(example => 
      example.id && 
      example.type && 
      ['approved', 'rejected'].includes(example.type) &&
      example.description && 
      example.reason
    )

    if (validExamples.length !== examples.length) {
      return NextResponse.json(
        { error: 'Alguns exemplos têm formato inválido' },
        { status: 400 }
      )
    }

    // Salvar exemplos (em memória por enquanto)
    savedExamples = validExamples

    console.log('Exemplos de treinamento salvos:', savedExamples.length)

    return NextResponse.json({
      success: true,
      message: `${savedExamples.length} exemplos salvos com sucesso`,
      count: savedExamples.length
    })

  } catch (error) {
    console.error('Erro ao salvar exemplos:', error)
    return NextResponse.json(
      { error: 'Erro interno ao salvar exemplos' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    return NextResponse.json({
      message: 'API de treinamento de IA',
      examples: savedExamples,
      count: savedExamples.length
    })
  } catch (error) {
    console.error('Erro ao buscar exemplos:', error)
    return NextResponse.json(
      { error: 'Erro interno ao buscar exemplos' },
      { status: 500 }
    )
  }
}