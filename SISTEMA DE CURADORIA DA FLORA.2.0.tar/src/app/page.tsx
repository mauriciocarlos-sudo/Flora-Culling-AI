'use client'

import { useState } from 'react'
import { PhotoCurator } from '@/components/photo-curator'
import { UploadArea } from '@/components/upload-area'
import { Header } from '@/components/header'
import { ProgressIndicator } from '@/components/progress-indicator'
import { ResultsPanel } from '@/components/results-panel'
import { AITrainer } from '@/components/ai-trainer'

export interface PhotoFile {
  id: string
  name: string
  file: File
  preview?: string
  status: 'pending' | 'processing' | 'approved' | 'rejected'
  rating?: number
  pick?: boolean
  analysis?: string
  xmpData?: string
}

export default function Home() {
  const [photos, setPhotos] = useState<PhotoFile[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentStep, setCurrentStep] = useState<'upload' | 'review' | 'results' | 'trainer'>('upload')

  const handlePhotosUpload = (uploadedPhotos: PhotoFile[]) => {
    setPhotos(uploadedPhotos)
    setCurrentStep('review')
  }

  const handlePhotoUpdate = (photoId: string, updates: Partial<PhotoFile>) => {
    setPhotos(prev => prev.map(photo => 
      photo.id === photoId ? { ...photo, ...updates } : photo
    ))
  }

  const handleBatchProcess = async () => {
    setIsProcessing(true)
    // Process photos sequentially
    for (const photo of photos.filter(p => p.status === 'pending')) {
      handlePhotoUpdate(photo.id, { status: 'processing' })
      
      try {
        const response = await fetch('/api/analyze-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            photoId: photo.id,
            fileName: photo.name
          })
        })
        
        const result = await response.json()
        
        handlePhotoUpdate(photo.id, {
          status: result.approved ? 'approved' : 'rejected',
          rating: result.rating,
          pick: result.pick,
          analysis: result.analysis,
          xmpData: result.xmpData
        })
      } catch (error) {
        handlePhotoUpdate(photo.id, { 
          status: 'rejected',
          analysis: 'Erro no processamento da imagem'
        })
      }
    }
    
    setIsProcessing(false)
    setCurrentStep('results')
  }

  const approvedPhotos = photos.filter(p => p.status === 'approved')
  const rejectedPhotos = photos.filter(p => p.status === 'rejected')
  const pendingPhotos = photos.filter(p => p.status === 'pending')

  return (
    <div className="min-h-screen bg-white">
      <Header 
        currentStep={currentStep}
        onStepChange={setCurrentStep}
        photosCount={photos.length}
        approvedCount={approvedPhotos.length}
      />
      
      <main className="container mx-auto px-4 py-8">
        {currentStep === 'upload' && (
          <UploadArea onPhotosUpload={handlePhotosUpload} />
        )}
        
        {currentStep === 'trainer' && (
          <AITrainer />
        )}
        
        {currentStep === 'review' && (
          <div className="space-y-6">
            <ProgressIndicator
              total={photos.length}
              processed={photos.filter(p => p.status !== 'pending').length}
              approved={approvedPhotos.length}
              rejected={rejectedPhotos.length}
              isProcessing={isProcessing}
            />
            
            <PhotoCurator
              photos={photos}
              onPhotoUpdate={handlePhotoUpdate}
              onBatchProcess={handleBatchProcess}
              isProcessing={isProcessing}
            />
          </div>
        )}
        
        {currentStep === 'results' && (
          <ResultsPanel
            approvedPhotos={approvedPhotos}
            rejectedPhotos={rejectedPhotos}
            allPhotos={photos}
          />
        )}
      </main>
    </div>
  )
}