'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { PhotoFile } from '@/app/page'
import { 
  Download,
  CheckCircle,
  XCircle,
  Star,
  FileImage,
  Archive,
  BarChart3,
  TrendingUp
} from 'lucide-react'

interface ResultsPanelProps {
  approvedPhotos: PhotoFile[]
  rejectedPhotos: PhotoFile[]
  allPhotos: PhotoFile[]
}

export function ResultsPanel({ 
  approvedPhotos, 
  rejectedPhotos, 
  allPhotos 
}: ResultsPanelProps) {
  const approvalRate = allPhotos.length > 0 ? (approvedPhotos.length / allPhotos.length) * 100 : 0
  
  const downloadAllXMP = () => {
    approvedPhotos.forEach((photo) => {
      if (photo.xmpData) {
        const blob = new Blob([photo.xmpData], { type: 'text/xml' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = photo.name.replace(/\.[^/.]+$/, '.xmp')
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
      }
    })
  }

  const downloadReport = () => {
    const report = {
      date: new Date().toISOString(),
      summary: {
        total: allPhotos.length,
        approved: approvedPhotos.length,
        rejected: rejectedPhotos.length,
        approvalRate: approvalRate.toFixed(1)
      },
      approved: approvedPhotos.map(p => ({
        name: p.name,
        rating: p.rating,
        analysis: p.analysis
      })),
      rejected: rejectedPhotos.map(p => ({
        name: p.name,
        analysis: p.analysis
      }))
    }

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `curadoria-report-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 text-center">
            <FileImage className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-900">{allPhotos.length}</div>
            <div className="text-sm text-gray-600">Total de Fotos</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-700">{approvedPhotos.length}</div>
            <div className="text-sm text-green-600">Aprovadas</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <XCircle className="h-8 w-8 text-red-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-red-700">{rejectedPhotos.length}</div>
            <div className="text-sm text-red-600">Rejeitadas</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-purple-700">{approvalRate.toFixed(1)}%</div>
            <div className="text-sm text-purple-600">Taxa de Aprovação</div>
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Archive className="h-5 w-5" />
            <span>Exportação</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              onClick={downloadAllXMP}
              disabled={approvedPhotos.length === 0}
              className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Baixar Todos os XMPs ({approvedPhotos.length})
            </Button>
            
            <Button
              onClick={downloadReport}
              variant="outline"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Baixar Relatório Completo
            </Button>
          </div>
          
          {approvalRate < 40 && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Observação:</strong> Taxa de aprovação abaixo do esperado. 
                Considere revisar os critérios ou a qualidade das fotos originais.
              </p>
            </div>
          )}
          {approvalRate >= 40 && approvalRate < 60 && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Bom trabalho:</strong> Taxa de aprovação razoável para curadoria profissional.
              </p>
            </div>
          )}
          {approvalRate >= 60 && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800">
                <strong>Excelente:</strong> Ótima taxa de aprovação! Qualidade fotográfica adequada.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Approved Photos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span>Fotos Aprovadas ({approvedPhotos.length})</span>
              </span>
              <Badge className="bg-green-100 text-green-800 border-green-200">
                {approvalRate.toFixed(1)}%
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {approvedPhotos.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    Nenhuma foto foi aprovada na curadoria
                  </p>
                ) : (
                  approvedPhotos.map((photo) => (
                    <div key={photo.id} className="p-4 border border-green-200 bg-green-50 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium text-gray-900 truncate flex-1">
                          {photo.name}
                        </h4>
                        <div className="flex items-center space-x-1 ml-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-3 w-3 ${
                                star <= (photo.rating || 0)
                                  ? 'text-yellow-500 fill-current'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      
                      {photo.analysis && (
                        <p className="text-sm text-gray-700 mb-2">
                          {photo.analysis}
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
                          Aprovada
                        </Badge>
                        
                        {photo.xmpData && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const blob = new Blob([photo.xmpData!], { type: 'text/xml' })
                              const url = URL.createObjectURL(blob)
                              const a = document.createElement('a')
                              a.href = url
                              a.download = photo.name.replace(/\.[^/.]+$/, '.xmp')
                              document.body.appendChild(a)
                              a.click()
                              document.body.removeChild(a)
                              URL.revokeObjectURL(url)
                            }}
                          >
                            <Download className="h-3 w-3 mr-1" />
                            XMP
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Rejected Photos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <XCircle className="h-5 w-5 text-red-600" />
              <span>Fotos Rejeitadas ({rejectedPhotos.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {rejectedPhotos.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    Todas as fotos foram aprovadas!
                  </p>
                ) : (
                  rejectedPhotos.map((photo) => (
                    <div key={photo.id} className="p-4 border border-red-200 bg-red-50 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium text-gray-900 truncate flex-1">
                          {photo.name}
                        </h4>
                        <Badge className="bg-red-100 text-red-800 border-red-200 text-xs">
                          Rejeitada
                        </Badge>
                      </div>
                      
                      {photo.analysis && (
                        <p className="text-sm text-gray-700">
                          {photo.analysis}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}