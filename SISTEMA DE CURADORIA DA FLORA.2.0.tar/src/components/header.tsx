'use client'

import { ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Camera, Upload, CheckCircle, XCircle, Brain } from 'lucide-react'

interface HeaderProps {
  currentStep: 'upload' | 'review' | 'results' | 'trainer'
  onStepChange: (step: 'upload' | 'review' | 'results' | 'trainer') => void
  photosCount: number
  approvedCount: number
}

export function Header({ currentStep, onStepChange, photosCount, approvedCount }: HeaderProps) {
  const steps = [
    { id: 'upload', label: 'Upload', icon: Upload },
    { id: 'trainer', label: 'Treinar IA', icon: Brain },
    { id: 'review', label: 'Análise', icon: Camera },
    { id: 'results', label: 'Resultados', icon: CheckCircle }
  ] as const

  return (
    <header className="border-b border-gray-200 bg-white">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Camera className="h-8 w-8 text-gray-900" />
              <h1 className="text-2xl font-bold text-gray-900">
                Curadoria Fotográfica Profissional
              </h1>
            </div>
            
            {photosCount > 0 && (
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-gray-700">
                  {photosCount} fotos
                </Badge>
                {approvedCount > 0 && (
                  <Badge 
                    className="bg-gradient-to-r from-pink-500 to-purple-600 text-white border-0"
                  >
                    {approvedCount} aprovadas
                  </Badge>
                )}
              </div>
            )}
          </div>
          
          <nav className="flex items-center space-x-1">
            {steps.map((step) => {
              const Icon = step.icon
              const isActive = currentStep === step.id
              const isCompleted = (step.id === 'upload' && photosCount > 0) ||
                                (step.id === 'trainer' && true) || // Sempre disponível
                                (step.id === 'review' && photosCount > 0) ||
                                (step.id === 'results' && approvedCount > 0)
              
              return (
                <Button
                  key={step.id}
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onStepChange(step.id)}
                  disabled={!isCompleted && step.id !== 'upload' && step.id !== 'trainer'}
                  className={`flex items-center space-x-2 ${
                    isActive 
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white border-0' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{step.label}</span>
                  {isCompleted && !isActive && (
                    <CheckCircle className="h-3 w-3 text-green-600" />
                  )}
                </Button>
              )
            })}
          </nav>
        </div>
      </div>
    </header>
  )
}