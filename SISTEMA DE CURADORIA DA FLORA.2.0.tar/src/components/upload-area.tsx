'use client'

import { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Upload, Image, FileImage, AlertCircle } from 'lucide-react'
import { PhotoFile } from '@/app/page'

interface UploadAreaProps {
  onPhotosUpload: (photos: PhotoFile[]) => void
}

export function UploadArea({ onPhotosUpload }: UploadAreaProps) {
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])

  const processFiles = async (files: File[]): Promise<PhotoFile[]> => {
    const photoFiles: PhotoFile[] = []
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      
      // Check if file is a supported RAW format
      const supportedFormats = ['.cr2', '.cr3', '.nef', '.arw', '.dng', '.orf', '.rw2', '.pef', '.srw', '.jpg', '.jpeg', '.tiff', '.tif', '.png', '.bmp', '.gif']
      const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'))
      
      if (!supportedFormats.includes(fileExtension)) {
        console.warn(`Formato não suportado: ${file.name}`)
        continue
      }
      
      // Create preview for image files
      let preview: string | undefined
      if (file.type.startsWith('image/')) {
        preview = await new Promise<string>((resolve) => {
          const reader = new FileReader()
          reader.onload = (e) => resolve(e.target?.result as string)
          reader.readAsDataURL(file)
        })
      }
      
      photoFiles.push({
        id: `${file.name}-${Date.now()}-${Math.random()}`,
        name: file.name,
        file,
        preview,
        status: 'pending'
      })
      
      // Update progress
      setUploadProgress(((i + 1) / files.length) * 100)
    }
    
    return photoFiles
  }

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return
    
    setIsUploading(true)
    setUploadProgress(0)
    
    try {
      const photoFiles = await processFiles(acceptedFiles)
      setUploadedFiles(photoFiles.map(p => p.name))
      onPhotosUpload(photoFiles)
    } catch (error) {
      console.error('Erro ao processar arquivos:', error)
    } finally {
      setIsUploading(false)
      setUploadProgress(0)
    }
  }, [onPhotosUpload])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.cr2', '.cr3', '.nef', '.arw', '.dng', '.orf', '.rw2', '.pef', '.srw', '.jpg', '.jpeg', '.tiff', '.tif', '.png', '.bmp', '.gif']
    },
    multiple: true,
    noClick: false,
    noKeyboard: false
  })

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors">
        <CardContent className="p-12">
          <div
            {...getRootProps()}
            className={`text-center cursor-pointer transition-all duration-200 ${
              isDragActive 
                ? 'bg-gradient-to-br from-pink-50 to-purple-50 border-purple-400' 
                : 'hover:bg-gray-50'
            }`}
          >
            <input {...getInputProps()} />
            
            <div className="flex flex-col items-center space-y-4">
              <div className="p-4 bg-gradient-to-br from-pink-100 to-purple-100 rounded-full">
                <Upload className="h-12 w-12 bg-gradient-to-r from-pink-600 to-purple-600" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-gray-900">
                  {isDragActive ? '✨ Solte as fotos aqui' : '📸 Carregue suas fotos'}
                </h3>
                <p className="text-gray-600">
                  {isDragActive 
                    ? 'Libere o mouse para começar o upload' 
                    : 'Arraste e solte ou clique para selecionar arquivos'
                  }
                </p>
                <p className="text-sm text-gray-500">
                  Suporta: RAW (CR2, NEF, ARW, DNG) e formatos comuns (JPG, PNG, TIFF)
                </p>
              </div>
              
              <Button 
                onClick={(e) => {
                  e.stopPropagation()
                  document.querySelector('input[type="file"]')?.click()
                }}
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                disabled={isUploading}
              >
                {isUploading ? '⏳ Processando...' : '📁 Selecionar Fotos'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {isUploading && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <FileImage className="h-5 w-5 text-gray-600" />
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900">
                    Processando arquivos...
                  </span>
                  <span className="text-sm text-gray-600">
                    {Math.round(uploadProgress)}%
                  </span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {uploadedFiles.length > 0 && !isUploading && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Image className="h-5 w-5 text-green-600" />
              <h4 className="font-semibold text-gray-900">
                {uploadedFiles.length} fotos carregadas com sucesso
              </h4>
            </div>
            
            <div className="max-h-32 overflow-y-auto space-y-1">
              {uploadedFiles.map((fileName, index) => (
                <div key={index} className="text-sm text-gray-600 flex items-center space-x-2">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  <span>{fileName}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
            <div className="space-y-1">
              <h4 className="font-semibold text-blue-900">Dica Profissional</h4>
              <p className="text-sm text-blue-800">
                Para melhores resultados, organize suas fotos em pastas por sessão fotográfica 
                antes de carregar. O sistema analisará cada imagem com critérios técnicos rigorosos 
                (nitidez, foco, composição) e emocionais (expressão, narrativa, impacto).
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

import { CheckCircle } from 'lucide-react'