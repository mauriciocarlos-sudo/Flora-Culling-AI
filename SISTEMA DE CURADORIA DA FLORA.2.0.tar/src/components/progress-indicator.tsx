'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { CheckCircle, XCircle, Clock, Camera } from 'lucide-react'

interface ProgressIndicatorProps {
  total: number
  processed: number
  approved: number
  rejected: number
  isProcessing: boolean
}

export function ProgressIndicator({ 
  total, 
  processed, 
  approved, 
  rejected, 
  isProcessing 
}: ProgressIndicatorProps) {
  const pending = total - processed
  const approvalRate = total > 0 ? (approved / total) * 100 : 0
  const overallProgress = total > 0 ? (processed / total) * 100 : 0

  return (
    <Card className="border-gray-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Camera className="h-5 w-5" />
          <span>Progresso da Curadoria</span>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Progresso Total</span>
            <span className="font-medium">{processed}/{total} fotos</span>
          </div>
          <Progress value={overallProgress} className="h-3" />
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-900">{total}</div>
            <div className="text-sm text-gray-600">Total</div>
          </div>
          
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-700">{pending}</div>
            <div className="text-sm text-yellow-600">Pendentes</div>
          </div>
          
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-700">{approved}</div>
            <div className="text-sm text-green-600">Aprovadas</div>
          </div>
          
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-700">{rejected}</div>
            <div className="text-sm text-red-600">Rejeitadas</div>
          </div>
        </div>

        {/* Approval Rate */}
        {processed > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Taxa de Aprovação</span>
              <Badge 
                variant={approvalRate >= 40 ? "default" : "secondary"}
                className={approvalRate >= 40 
                  ? "bg-gradient-to-r from-pink-500 to-purple-600 text-white border-0" 
                  : "bg-gray-200 text-gray-700"
                }
              >
                {approvalRate.toFixed(1)}%
              </Badge>
            </div>
            <Progress value={approvalRate} className="h-2" />
            {approvalRate < 40 && (
              <p className="text-xs text-gray-500 italic">
                Taxa de aprovação abaixo do esperado. Considere revisar os critérios ou a qualidade das fotos.
              </p>
            )}
            {approvalRate >= 40 && approvalRate < 60 && (
              <p className="text-xs text-green-600 italic">
                Taxa de aprovação razoável para curadoria profissional.
              </p>
            )}
            {approvalRate >= 60 && (
              <p className="text-xs text-green-600 italic">
                Boa taxa de aprovação! Qualidade fotográfica adequada.
              </p>
            )}
          </div>
        )}

        {/* Status Messages */}
        {isProcessing && (
          <div className="flex items-center space-x-2 p-3 bg-blue-50 rounded-lg">
            <Clock className="h-4 w-4 text-blue-600 animate-spin" />
            <span className="text-sm text-blue-800">
              Processando fotos com análise técnica e emocional...
            </span>
          </div>
        )}

        {processed === total && total > 0 && (
          <div className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span className="text-sm text-green-800">
              Curadoria concluída! {approved} fotos selecionadas para edição.
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}