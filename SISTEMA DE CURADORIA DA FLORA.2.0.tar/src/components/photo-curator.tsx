'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { PhotoFile } from '@/app/page'
import { 
  Eye, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Star,
  Download,
  Play,
  Pause
} from 'lucide-react'

interface PhotoCuratorProps {
  photos: PhotoFile[]
  onPhotoUpdate: (photoId: string, updates: Partial<PhotoFile>) => void
  onBatchProcess: () => void
  isProcessing: boolean
}

export function PhotoCurator({ 
  photos, 
  onPhotoUpdate, 
  onBatchProcess, 
  isProcessing 
}: PhotoCuratorProps) {
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoFile | null>(null)
  const [isPaused, setIsPaused] = useState(false)

  const getStatusIcon = (status: PhotoFile['status']) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-600" />
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-600 animate-spin" />
      default:
        return <Clock className="h-4 w-4 text-gray-400" />
    }
  }

  const getStatusBadge = (status: PhotoFile['status']) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Aprovada</Badge>
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Rejeitada</Badge>
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Processando</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Pendente</Badge>
    }
  }

  const getRatingStars = (rating?: number) => {
    if (!rating) return null
    
    return (
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating 
                ? 'text-yellow-500 fill-current' 
                : 'text-gray-300'
            }`}
          />
        ))}
      </div>
    )
  }

  const pendingPhotos = photos.filter(p => p.status === 'pending')
  const processingPhotos = photos.filter(p => p.status === 'processing')
  const processedPhotos = photos.filter(p => p.status !== 'pending' && p.status !== 'processing')

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Photo List */}
      <div className="lg:col-span-1">
        <Card className="h-[600px]">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Fotos ({photos.length})</CardTitle>
            
            {/* Batch Controls */}
            <div className="flex space-x-2 pt-2">
              <Button
                onClick={onBatchProcess}
                disabled={pendingPhotos.length === 0 || isProcessing}
                className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
              >
                {isProcessing ? (
                  <>
                    <Pause className="h-4 w-4 mr-2" />
                    Pausar
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Processar Todas ({pendingPhotos.length})
                  </>
                )}
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            <ScrollArea className="h-[500px]">
              <div className="p-4 space-y-2">
                {/* Pending Photos */}
                {pendingPhotos.length > 0 && (
                  <>
                    <div className="text-sm font-medium text-gray-700 mb-2">
                      Pendentes ({pendingPhotos.length})
                    </div>
                    {pendingPhotos.map((photo) => (
                      <div
                        key={photo.id}
                        onClick={() => setSelectedPhoto(photo)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                          selectedPhoto?.id === photo.id
                            ? 'border-purple-500 bg-purple-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {photo.preview ? (
                              <img
                                src={photo.preview}
                                alt={photo.name}
                                className="h-12 w-12 object-cover rounded"
                              />
                            ) : (
                              <div className="h-12 w-12 bg-gray-200 rounded flex items-center justify-center">
                                <Eye className="h-5 w-5 text-gray-400" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {photo.name}
                              </p>
                              <div className="flex items-center space-x-2 mt-1">
                                {getStatusBadge(photo.status)}
                              </div>
                            </div>
                          </div>
                          {getStatusIcon(photo.status)}
                        </div>
                      </div>
                    ))}
                    <Separator className="my-4" />
                  </>
                )}

                {/* Processing Photos */}
                {processingPhotos.length > 0 && (
                  <>
                    <div className="text-sm font-medium text-gray-700 mb-2">
                      Processando ({processingPhotos.length})
                    </div>
                    {processingPhotos.map((photo) => (
                      <div
                        key={photo.id}
                        className="p-3 rounded-lg border border-blue-200 bg-blue-50"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {photo.preview ? (
                              <img
                                src={photo.preview}
                                alt={photo.name}
                                className="h-12 w-12 object-cover rounded"
                              />
                            ) : (
                              <div className="h-12 w-12 bg-gray-200 rounded flex items-center justify-center">
                                <Eye className="h-5 w-5 text-gray-400" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {photo.name}
                              </p>
                              {getStatusBadge(photo.status)}
                            </div>
                          </div>
                          {getStatusIcon(photo.status)}
                        </div>
                      </div>
                    ))}
                    <Separator className="my-4" />
                  </>
                )}

                {/* Processed Photos */}
                {processedPhotos.length > 0 && (
                  <>
                    <div className="text-sm font-medium text-gray-700 mb-2">
                      Processadas ({processedPhotos.length})
                    </div>
                    {processedPhotos.map((photo) => (
                      <div
                        key={photo.id}
                        onClick={() => setSelectedPhoto(photo)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                          selectedPhoto?.id === photo.id
                            ? 'border-purple-500 bg-purple-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {photo.preview ? (
                              <img
                                src={photo.preview}
                                alt={photo.name}
                                className="h-12 w-12 object-cover rounded"
                              />
                            ) : (
                              <div className="h-12 w-12 bg-gray-200 rounded flex items-center justify-center">
                                <Eye className="h-5 w-5 text-gray-400" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate">
                                {photo.name}
                              </p>
                              <div className="flex items-center space-x-2 mt-1">
                                {getStatusBadge(photo.status)}
                                {photo.rating && getRatingStars(photo.rating)}
                              </div>
                            </div>
                          </div>
                          {getStatusIcon(photo.status)}
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Photo Preview & Analysis */}
      <div className="lg:col-span-2">
        {selectedPhoto ? (
          <Card className="h-[600px]">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{selectedPhoto.name}</span>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(selectedPhoto.status)}
                  {selectedPhoto.rating && getRatingStars(selectedPhoto.rating)}
                </div>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {/* Photo Preview */}
              <div className="flex justify-center">
                {selectedPhoto.preview ? (
                  <img
                    src={selectedPhoto.preview}
                    alt={selectedPhoto.name}
                    className="max-w-full max-h-80 object-contain rounded-lg shadow-lg"
                  />
                ) : (
                  <div className="w-full h-80 bg-gray-100 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <Eye className="h-16 w-16 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">Preview não disponível</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Analysis Results */}
              {selectedPhoto.analysis && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Análise da Curadoria</h4>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {selectedPhoto.analysis}
                    </p>
                  </div>
                </div>
              )}

              {/* Technical Details */}
              {selectedPhoto.status !== 'pending' && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Detalhes Técnicos</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Status:</span>
                      <div className="font-medium">{getStatusBadge(selectedPhoto.status)}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Rating:</span>
                      <div className="font-medium">
                        {selectedPhoto.rating ? `${selectedPhoto.rating}/5` : 'N/A'}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-600">Pick:</span>
                      <div className="font-medium">
                        {selectedPhoto.pick ? 'Sim' : 'Não'}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-600">XMP:</span>
                      <div className="font-medium">
                        {selectedPhoto.xmpData ? 'Gerado' : 'Não gerado'}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Download XMP */}
              {selectedPhoto.xmpData && (
                <Button
                  onClick={() => {
                    const blob = new Blob([selectedPhoto.xmpData!], { type: 'text/xml' })
                    const url = URL.createObjectURL(blob)
                    const a = document.createElement('a')
                    a.href = url
                    a.download = selectedPhoto.name.replace(/\.[^/.]+$/, '.xmp')
                    document.body.appendChild(a)
                    a.click()
                    document.body.removeChild(a)
                    URL.revokeObjectURL(url)
                  }}
                  className="w-full"
                  variant="outline"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Baixar Arquivo XMP
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card className="h-[600px] flex items-center justify-center">
            <CardContent className="text-center">
              <Eye className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma foto selecionada
              </h3>
              <p className="text-gray-600">
                Selecione uma foto da lista para visualizar os detalhes da análise
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}