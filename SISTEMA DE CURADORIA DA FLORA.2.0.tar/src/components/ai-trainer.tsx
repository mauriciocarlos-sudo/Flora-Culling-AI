'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Brain, 
  Plus, 
  Trash2, 
  CheckCircle, 
  XCircle,
  Lightbulb,
  Camera,
  Heart,
  Image as ImageIcon
} from 'lucide-react'

interface LearningExample {
  id: string
  type: 'approved' | 'rejected'
  description: string
  reason: string
  timestamp: Date
}

interface AITrainerProps {
  onExamplesUpdate?: (examples: LearningExample[]) => void
}

export function AITrainer({ onExamplesUpdate }: AITrainerProps) {
  const [examples, setExamples] = useState<LearningExample[]>([
    {
      id: '1',
      type: 'approved',
      description: 'Retratos familiares com sorrisos naturais e boa iluminação',
      reason: 'Capturam momentos genuínos de conexão familiar',
      timestamp: new Date()
    },
    {
      id: '2',
      type: 'approved',
      description: 'Crianças brincando com expressões espontâneas',
      reason: 'Momentos autênticos que mostram personalidade',
      timestamp: new Date()
    },
    {
      id: '3',
      type: 'rejected',
      description: 'Pessoas com olhos fechados ou em meio piscada',
      reason: 'Expressão facial comprometida, não funciona profissionalmente',
      timestamp: new Date()
    },
    {
      id: '4',
      type: 'rejected',
      description: 'Mãos ou pés cortados de forma estranha',
      reason: 'Cortes que destroem a composição e parecem erros',
      timestamp: new Date()
    }
  ])
  
  const [newExample, setNewExample] = useState({
    type: 'approved' as 'approved' | 'rejected',
    description: '',
    reason: ''
  })

  const [isAdding, setIsAdding] = useState(false)

  const addExample = () => {
    if (!newExample.description.trim() || !newExample.reason.trim()) {
      return
    }

    const example: LearningExample = {
      id: Date.now().toString(),
      type: newExample.type,
      description: newExample.description,
      reason: newExample.reason,
      timestamp: new Date()
    }

    const updatedExamples = [...examples, example]
    setExamples(updatedExamples)
    onExamplesUpdate?.(updatedExamples)

    setNewExample({
      type: 'approved',
      description: '',
      reason: ''
    })
    setIsAdding(false)
  }

  const removeExample = (id: string) => {
    const updatedExamples = examples.filter(ex => ex.id !== id)
    setExamples(updatedExamples)
    onExamplesUpdate?.(updatedExamples)
  }

  const saveToAPI = async () => {
    try {
      const response = await fetch('/api/save-examples', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ examples })
      })
      
      const result = await response.json()
      
      if (result.success) {
        alert('✅ Exemplos salvos com sucesso! A IA aprenderá com suas preferências.')
      } else {
        alert('❌ Erro ao salvar exemplos: ' + result.error)
      }
    } catch (error) {
      console.error('Erro ao salvar exemplos:', error)
      alert('❌ Erro ao salvar exemplos. Tente novamente.')
    }
  }

  const approvedExamples = examples.filter(ex => ex.type === 'approved')
  const rejectedExamples = examples.filter(ex => ex.type === 'rejected')

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-600" />
            <span>Treinador de IA</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            Ensine a IA a reconhecer suas preferências fotográficas. Adicione exemplos de fotos que você aprova ou rejeita com motivos claros.
          </p>
          
          <Button
            onClick={() => setIsAdding(!isAdding)}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Exemplo
          </Button>
        </CardContent>
      </Card>

      {/* Add New Example */}
      {isAdding && (
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="text-lg">Novo Exemplo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Tipo de Exemplo
              </label>
              <div className="flex space-x-2">
                <Button
                  variant={newExample.type === 'approved' ? 'default' : 'outline'}
                  onClick={() => setNewExample({...newExample, type: 'approved'})}
                  className="flex-1"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Foto Aprovada
                </Button>
                <Button
                  variant={newExample.type === 'rejected' ? 'default' : 'outline'}
                  onClick={() => setNewExample({...newExample, type: 'rejected'})}
                  className="flex-1"
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Foto Rejeitada
                </Button>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Descrição da Foto
              </label>
              <Textarea
                placeholder="Ex: Retratos de casal se olhando nos olhos com luz suave"
                value={newExample.description}
                onChange={(e) => setNewExample({...newExample, description: e.target.value})}
                rows={3}
              />
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Motivo da Decisão
              </label>
              <Textarea
                placeholder="Ex: Mostra conexão genuína e composição equilibrada"
                value={newExample.reason}
                onChange={(e) => setNewExample({...newExample, reason: e.target.value})}
                rows={2}
              />
            </div>

            <div className="flex space-x-2">
              <Button
                onClick={addExample}
                disabled={!newExample.description.trim() || !newExample.reason.trim()}
                className="flex-1"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Adicionar
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setIsAdding(false)
                  setNewExample({
                    type: 'approved',
                    description: '',
                    reason: ''
                  })
                }}
              >
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Examples Display */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Approved Examples */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-green-700">
              <CheckCircle className="h-5 w-5" />
              <span>Fotos Aprovadas ({approvedExamples.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {approvedExamples.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    Nenhum exemplo de foto aprovada ainda
                  </p>
                ) : (
                  approvedExamples.map((example) => (
                    <div key={example.id} className="p-4 border border-green-200 bg-green-50 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <Badge className="bg-green-100 text-green-800 border-green-200">
                          <Camera className="h-3 w-3 mr-1" />
                          Aprovada
                        </Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeExample(example.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <p className="text-sm font-medium text-gray-900 mb-2">
                        {example.description}
                      </p>
                      
                      <div className="flex items-start space-x-2">
                        <Heart className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-gray-700">
                          {example.reason}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Rejected Examples */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-700">
              <XCircle className="h-5 w-5" />
              <span>Fotos Rejeitadas ({rejectedExamples.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {rejectedExamples.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    Nenhum exemplo de foto rejeitada ainda
                  </p>
                ) : (
                  rejectedExamples.map((example) => (
                    <div key={example.id} className="p-4 border border-red-200 bg-red-50 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <Badge className="bg-red-100 text-red-800 border-red-200">
                          <ImageIcon className="h-3 w-3 mr-1" />
                          Rejeitada
                        </Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeExample(example.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <p className="text-sm font-medium text-gray-900 mb-2">
                        {example.description}
                      </p>
                      
                      <div className="flex items-start space-x-2">
                        <XCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-gray-700">
                          {example.reason}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Save Button */}
      <Card className="bg-purple-50 border-purple-200">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <Lightbulb className="h-5 w-5 text-purple-600" />
            <div className="flex-1">
              <h4 className="font-semibold text-purple-900">Dica de Treinamento</h4>
              <p className="text-sm text-purple-800">
                Quanto mais exemplos específicos você adicionar, mais a IA aprenderá suas preferências únicas.
              </p>
            </div>
            <Button
              onClick={saveToAPI}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Salvar Treinamento
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}